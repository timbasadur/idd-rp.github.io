# Interaction Design: Course Website

This is a **placeholder** _document_.


## Meeting Notes: Sept 11, 2019

### Content List

- Header
  - Program Description
  - Courses list 
  - Tuition fees
  - Career Opportunities
  - Why Interaction Design
  - How to Apply - button that links directly

Testimonials
Applications that were using
Instructor profiles
Why you should hire our alumni
- Footer
  - Copyright
  - Social media links

### Design Guide

#### Colours
- Back: `#ff45a6`: Redieblue, On: `#aabbcc`
- 